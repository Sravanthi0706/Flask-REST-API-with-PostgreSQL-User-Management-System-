from app import app
from flask import request
from models.my_model import my_model
obj = my_model()
from models.user_register import user_register
reg_obj = user_register()


@app.route("/freek/home", methods=["GET"])
def home():
    return obj.my_new_model()

@app.route("/user/v1/register", methods=["POST"])
def register():
    return  reg_obj.registration(request.json)


@app.route("/freek/update",methods=["POST"])
def update():
   return obj.updater(request.form)

@app.route("/freek/delete",methods=["POST"])
def delete():
   return obj.deleter(request.form)


@app.route("/freek/limit/<limit>/page/<page>",methods=["GET"])
def pagination(limit, page):
   return obj.pagenation(limit, page)
