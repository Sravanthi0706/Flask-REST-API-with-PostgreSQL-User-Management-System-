import psycopg2
import psycopg2.extras
from configs.config import dbconfig
from flask import make_response
from models.validator import validator
from models.random_keygen import random_keygen


obj_val = validator()
obj_enc = random_keygen()

class user_register():
    def __init__(self):
        try:
            self.conn = psycopg2.connect(database = dbconfig['database'], 
                        user = dbconfig['username'], 
                        host= dbconfig['host'],
                        password = dbconfig['password'],
                        port = dbconfig['port'])
            print("Connection Succesfull")
        except:
            print("Connection Error")

    def registration(self,data):
        try:
            first_name = data['first_name']
            last_name = data['last_name']
            email_id = data['email_id']
            phone_number = data['phone_number']
            user_name = data['user_name']
            passwd = data['password']
            random_key = obj_enc.random_keygen()
            for x in first_name, last_name:
                name = obj_val.name(x)
                if name == "next":
                    mail = obj_val.email(email_id)
                    if mail == "next":
                        phone = obj_val.phone(phone_number)
                        if phone == "next":
                            username = obj_val.username(user_name)
                            if username == "next":
                                passw = obj_val.password(passwd)
                                if passw == "next":
                                    self.cur = self.conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
                                    self.cur.execute("insert into freek_guru_schema.fk_user_details(first_name,last_name,email_id,phone_no,user_random_key,user_name) values(%s,%s,%s,%s,%s,%s)",(first_name,last_name,email_id,phone_number,random_key,user_name))
                                    self.cur.execute("insert into freek_guru_schema.fk_user_creds(user_name,user_password,cred_random_key) values(%s,%s,%s)",(user_name,passwd,random_key))
                                    self.conn.commit()
                                    self.cur.close()
                                    return make_response({"message":"User successfully created"}, 200)
                                else:
                                    return passw
                            else:
                                return username
                        else:
                            return phone
                    else:
                        return mail
                else:
                    return name
        except:
            return make_response({"message":"unable to create user"},400)