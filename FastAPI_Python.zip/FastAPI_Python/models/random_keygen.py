from datetime import datetime, timedelta
import hashlib

class random_keygen():
    def random_keygen(self):
        exptime = datetime.now()
        epoc_time = exptime.timestamp()
        new_time = str(epoc_time).replace('.','')
        enc_val = hashlib.md5(new_time.encode())
        return str(enc_val.hexdigest())

