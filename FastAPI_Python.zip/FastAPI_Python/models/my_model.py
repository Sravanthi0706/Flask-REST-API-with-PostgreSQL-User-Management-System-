import psycopg2
import psycopg2.extras
import json
from flask import make_response
from configs.config import dbconfig

class my_model():
    def __init__(self):
        try:
            self.conn = psycopg2.connect(database = dbconfig['database'], 
                        user = dbconfig['username'], 
                        host= dbconfig['host'],
                        password = dbconfig['password'],
                        port = dbconfig['port'])
            print("Connection Succesfull")
        except:
            print("Connection Error")

    def my_new_model(self):
        try:
            self.cur = self.conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
            self.cur.execute('Select * from freek_guru_schema.user_auth_table')
            result = self.cur.fetchall()
            ans1 = []
            if len(result)>0:
                for row in result:
                    ans1.append(dict(row))
                res = make_response(ans1, 200)
                res.headers['Access-Control-Allow-Origin'] = "*"
                return res
                self.cur.close()
            else:
                self.cur.close()
                res = make_response({"message":"No data found"}, 204)
                res.headers['Access-Control-Allow-Origin'] = "*"
                return res
        except:
            return make_response({"message":"We recieved an error"}, 404)
        
    def registration(self,data):
        try:
            uname=str(data['username'])
            passwd=str(data['password'])
            ukey=int("123453123")
            self.cur = self.conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
            self.cur.execute("insert into freek_schema.user_auth_table(user_name,user_pass,user_key) values(%s,%s,%s)",(uname,passwd,ukey))
            self.conn.commit()
            self.cur.close()
            res =  make_response({"message":"User Created Successfully"},201)
            res.headers['Access-Control-Allow-Origin'] = "*"
            return res
        except:
            return make_response({"message":"unable to create user"},400)
    
    def updater(self, data):
        try:
            uname=str(data['username'])
            ukey=str("123453123")
            self.cur = self.conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
            self.cur.execute("update freek_schema.user_auth_table set user_pass=%s where user_key=%s",(uname,ukey))
            self.conn.commit()
            self.cur.close()
            res = make_response({"message":"The record update successfully"},202)
            res.headers['Access-Control-Allow-Origin'] = "*"
            return res
        except:
           return make_response({"message":"Unable to update user data"},400)

    def deleter(self, data):
       try:
        ukey=str(data['user_key'])
        print(ukey)
        self.cur = self.conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
        self.cur.execute("delete from freek_schema.user_auth_table where user_key=%s", [ukey])
        self.conn.commit()
        self.cur.close()
        res = make_response({"message":"The user deleted successfully"},410)
        res.headers['Access-Control-Allow-Origin'] = "*"
        return res
       except:
           return make_response({"message":"We are unable to delete the user"},400)
       

    def pagenation(self, limit, page):
        limit = int(limit)
        page = int(page)
        page_limit = (limit * page) - limit
        if page_limit == 0:
            page_limit = 1
        self.cur = self.conn.cursor(cursor_factory=psycopg2.extras.DictCursor)
        self.cur.execute("Select * from freek_schema.user_auth_table limit %s offset %s", (page_limit, page))
        result = self.cur.fetchall()
        new = []
        if len(result)>0:
            for me in result:
                new.append(dict(me))
            res = make_response(new, 200)
            res.headers['Access-Control-Allow-Origin'] = "*"
            return res
        else:
            return make_response({"message":"We are unable to delete the user"}, 400)




