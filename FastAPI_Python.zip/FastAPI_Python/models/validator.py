from flask import make_response
import re
class validator():
    def name(self,data):
        try:
            if len(data)>0:
                if len(data)>15:
                    return make_response({"message":"username_too_long_err"}, 200)
                else:
                    if data.replace(' ','').isalpha():
                        print("I am checking isalpha")
                        return "next"
                    else:
                        return make_response({"message":"username_err"}, 200)
            else:
                   return make_response({"message":"username_null_err"}, 200)
        except:
            return make_response({"message":"username_error"}, 404)
        
    def email(self,data):
        regex = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,7}\b'
        try:
            if len(data)>0:
                if len(data)>45:
                    return make_response({"message":"username_too_long_err"}, 200)
                else:
                    if re.fullmatch(regex, data):
                        print("I am checking email")
                        return "next"
                    else:
                        return make_response({"message":"email_err"}, 200)
            else:
                   return make_response({"message":"email_null_err"}, 200)
        except:
            return make_response({"message":"email_error"}, 404)
        
    def phone(self,data):
        try:
            if len(data)>0:
                if len(data)>11:
                    return make_response({"message":"username_too_long_err"}, 200)
                else:
                    if data.isdigit():
                        print("I am checking phone number")
                        return "next"
                    else:
                        return make_response({"message":"phone_number_err"}, 200)
            else:
                   return make_response({"message":"phone_number_null_err"}, 200)
        except:
            return make_response({"message":"phone_number_error"}, 404)
        

    def username(self, data):
        uname_regex= "^[A-Za-z][A-Za-z0-9_]{7,29}$"
        try:
            if len(data)>7:
                if len(data)>29:
                    return make_response({"message":"username_too_long_err"}, 200)
                else:
                    if re.fullmatch(uname_regex, data):
                        print("I am checking username")
                        return "next"
                    else:
                        if str(data[-1] ) == '_':
                            print("cheking _ value")
                            return make_response({"message":"username_err"}, 200)
                        else:
                            return make_response({"message":"username_err"}, 200)
            else:
                   return make_response({"message":"username_null_err"}, 200)
        except:
            return make_response({"message":"username_error"}, 404)


    def password(self, data):
        pass_regex= "[A-Za-z0-9@#$%^&+=]{8,45}"
        try:
            if len(data)>7:
                if len(data)>44:
                    return make_response({"message":"password_too_long_err"}, 200)
                else:
                    if re.fullmatch(pass_regex, data):
                        print("I am checking password")
                        return "next"
                    else:
                        return make_response({"message":"password_err"}, 200)
            else:
                   return make_response({"message":"password_null_err"}, 200)
        except:
            return make_response({"message":"password_error"}, 404)



