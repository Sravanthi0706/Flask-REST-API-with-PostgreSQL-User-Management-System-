dbconfig = {
    "host":"192.168.0.10",
    "port":"5432",
    "username":"Username",
    "password":"password@123",
    "database":"mydb"
}